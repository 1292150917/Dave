define({
  "name": "yjhl",
  "version": "1.0.0",
  "description": "",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2020-07-17T00:50:45.865Z",
    "url": "http://apidocjs.com",
    "version": "0.23.0"
  }
});
